
def debugger(message):
    print_debug_data = False
    if print_debug_data == True:
        print(message)